import { Component } from '@angular/core';

@Component({
  selector: 'app-inserir-usuario',
  standalone: false,
  templateUrl: './inserir-usuario.component.html',
  styleUrl: './inserir-usuario.component.css'
})
export class InserirUsuarioComponent {

}
